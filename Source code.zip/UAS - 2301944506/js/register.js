

function validasi(e) {
    e.preventDefault()

    var emailval = document.getElementById("email").value;
    var namaval = document.getElementById("nama").value;
    var alamatval = document.getElementById("alamat").value;
    var tglval = document.getElementById("tanggal-lahir").value;
    var telval = document.getElementById("tel").value;


    if (!(emailval != "" && namaval!="" && alamatval!="" && tglval!="" && telval!="")) {
        alert('You have to fill the form!'); 
    }else if(namaval.length < 3){
        alert('name is too short');
    }else if (!alamatval.startsWith("jalan")){
        alert(' adress must contain "jalan" ');
    }else if (telval.length < 11){
        alert('Phone number must contain at least 11 number')
    }else if(!(emailval.indexOf("@")>=0) && !emailval.endsWith(".com")) {
        alert('Invalid email type');
    }else{
        alert('Success!');
        window.location="login.html";
    }

    }

   