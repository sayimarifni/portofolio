function validasi(e) {
    e.preventDefault()

    var emailval = document.getElementById("email").value;
    var namaval = document.getElementById("nama").value;
    var mesval = document.getElementById("message").value;

    if (!(emailval != "" && namaval!="" && mesval!="" )) {
        alert('You have to fill the form!'); 
    }else if(namaval.length < 3){
        alert('name is too short');
    }else if(!(emailval.indexOf("@")>=0) && !emailval.endsWith(".com")) {
        alert('Invalid email type');
    }else if(mesval.length < 10){
        alert('message must contain at least 10 character!')
    }else{
        alert('Success to send message!');
    }

    }
