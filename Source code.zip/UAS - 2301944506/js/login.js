    function isAlphanumeric(word){
        let alphabet = false;
        let numeric = false;
        let uppercase= false;
    
        for(let i = 0; i < word.length; i++){
            if(word.charCodeAt(i) >= 48 && word.charCodeAt(i) <= 57){
                numeric = true
            }else if(word.charCodeAt(i) >= 97 && word.charCodeAt(i) <= 122){
                alphabet = true
            }else if(word.charCodeAt(i) >=65 && word.charCodeAt(i) <= 92)
                uppercase = true
        }
    
        if(alphabet == true && numeric == true && uppercase== true){
            return true
        }else{
            return false
        }
    }

    function validasi(e) {
        e.preventDefault()

        var emailval = document.getElementById("email").value;
        var passval = document.getElementById("password").value;
        

		if (!(emailval != "" && passval!="")) {
			alert('You have to fill the form!'); 
		}else if(!(emailval.indexOf("@")>=0) && !emailval.endsWith(".com")) {
            alert("Invalid email type");
        }else if(passval.length < 8){
            alert("password is too short");
        }else if (passval.length > 10){
            alert("password is too long");
        }else if (!isAlphanumeric(passval)){
            alert("password must contain combination uppercase, lowercase, and number");
        }else{
            alert('Success!');
            window.location="home.html";
        }

        }
		
        
	
